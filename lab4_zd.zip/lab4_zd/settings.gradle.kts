rootProject.name = "lab4_zd"

